package com.example.coursecrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoursecrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
