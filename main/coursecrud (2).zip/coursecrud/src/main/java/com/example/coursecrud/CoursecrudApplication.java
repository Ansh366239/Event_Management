package com.example.coursecrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoursecrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoursecrudApplication.class, args);
	}

}
